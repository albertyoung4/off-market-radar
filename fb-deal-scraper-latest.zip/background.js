/**
 * FB Deal Scraper — Background Service Worker
 * Queues captured posts in IndexedDB, syncs to Supabase cloud database.
 */

import { SUPABASE_URL, SUPABASE_ANON_KEY } from './config.js';

const DB_NAME = 'FBDealScraperQueue';
const DB_VERSION = 1;
const STORE_NAME = 'posts';
const BATCH_SIZE = 50;
const EXT_VERSION = chrome.runtime.getManifest().version;

/* ───────── IndexedDB ───────── */

function openDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        store.createIndex('status', 'status', { unique: false });
        store.createIndex('capturedAt', 'capturedAt', { unique: false });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function dbPut(db, record) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).put(record);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

function dbGetAllByStatus(db, statuses) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const req = store.getAll();
    req.onsuccess = () => {
      const results = req.result.filter(r => statuses.includes(r.status));
      resolve(results);
    };
    req.onerror = () => reject(req.error);
  });
}

function dbGetAll(db) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const req = tx.objectStore(STORE_NAME).getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function dbDeleteByStatus(db, status) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const req = store.index('status').openCursor(IDBKeyRange.only(status));
    req.onsuccess = (e) => {
      const cursor = e.target.result;
      if (cursor) {
        cursor.delete();
        cursor.continue();
      }
    };
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

/* ───────── Hashing ───────── */

async function hashPost(text) {
  const data = new TextEncoder().encode(text.trim());
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

/* ───────── Contact Extraction ───────── */

function extractPhones(text) {
  const raw = text.match(/(\+?1[\s\-.]?)?(\(?\d{3}\)?[\s\-.]?\d{3}[\s\-.]?\d{4})/g) || [];
  return [...new Set(raw.map(p => p.replace(/\s/g, '').trim()).filter(p => p.replace(/\D/g, '').length >= 10))];
}

function extractEmails(text) {
  const raw = text.match(/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g) || [];
  return [...new Set(raw)];
}

/* ───────── Poster Upsert ───────── */

async function upsertPoster(posterName, posterProfileUrl, phones, emails) {
  // Still create a poster if we have contact info (phone/email), even without a name
  if (!posterName && !posterProfileUrl && phones.length === 0 && emails.length === 0) return null;
  // Use a placeholder name if we have contact info but no name
  if (!posterName && !posterProfileUrl) {
    posterName = phones[0] || emails[0] || '';
  }
  try {
    const resp = await fetch(`${SUPABASE_URL}/rest/v1/rpc/upsert_poster`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
      },
      body: JSON.stringify({
        p_fb_name: posterName || '',
        p_fb_profile_url: posterProfileUrl || null,
        p_phones: phones,
        p_emails: emails,
      }),
    });
    if (resp.ok) {
      return await resp.json(); // returns the poster UUID
    }
    const errText = await resp.text();
    console.warn('[FB Deal Scraper] Poster upsert failed:', resp.status, errText.substring(0, 200));
    return null;
  } catch (err) {
    console.warn('[FB Deal Scraper] Poster upsert error:', err.message);
    return null;
  }
}

/* ───────── Queue ───────── */

async function queuePost(data) {
  const config = await chrome.storage.local.get(['collectorName']);
  const collectorName = (config.collectorName || '').trim();
  if (!collectorName) {
    return { success: false, error: 'Collector name not set' };
  }
  const postHash = await hashPost(data.postText);

  const record = {
    id: crypto.randomUUID(),
    postText: data.postText,
    postHash,
    images: data.images || [],
    posterName: data.posterName || '',
    posterProfileUrl: data.posterProfileUrl || '',
    postTimestamp: data.timestamp || '',
    groupName: data.groupName || '',
    postUrl: data.postUrl || '',
    collectorName,
    capturedAt: new Date().toISOString(),
    status: 'queued',
    syncAttempts: 0,
    syncError: null,
    lastSyncAttempt: null,
  };

  const db = await openDb();
  await dbPut(db, record);
  db.close();

  await updateBadge();
  return record.id;
}

/* ───────── Supabase Sync ───────── */

async function syncQueue() {
  if (!SUPABASE_URL || SUPABASE_URL.includes('YOUR_PROJECT_ID')) {
    console.log('[FB Deal Scraper] Supabase not configured, skipping sync.');
    return { synced: 0, errors: 0 };
  }

  let db;
  try {
    db = await openDb();
    const pending = await dbGetAllByStatus(db, ['queued', 'error']);

    if (pending.length === 0) {
      db.close();
      return { synced: 0, errors: 0 };
    }

    const batch = pending.slice(0, BATCH_SIZE);

    // Mark as syncing
    for (const record of batch) {
      record.status = 'syncing';
      record.lastSyncAttempt = new Date().toISOString();
      await dbPut(db, record);
    }

    // Build Supabase payload
    const rows = batch.map(r => ({
      post_text: r.postText,
      post_hash: r.postHash,
      post_images: r.images,
      poster_name: r.posterName,
      group_name: r.groupName,
      post_url: r.postUrl,
      post_timestamp: r.postTimestamp || null,
      collector_name: r.collectorName,
      captured_at: r.capturedAt,
      scraper_version: EXT_VERSION,
    }));
    // poster_id is set per-row in the loop below after upserting the poster

    // Send one at a time to handle duplicates gracefully
    // (ignore-duplicates header requires SELECT which we don't grant to anon)
    let synced = 0;
    let dupes = 0;
    let errors = 0;

    // Broadcast progress so the popup can show a live counter
    async function reportProgress() {
      await chrome.storage.local.set({
        syncProgress: { current: synced + dupes + errors, total: rows.length, synced, dupes, errors, active: true }
      });
    }
    await reportProgress();

    for (let i = 0; i < rows.length; i++) {
      // Upsert the poster and get back their ID
      const phones = extractPhones(batch[i].postText);
      const emails = extractEmails(batch[i].postText);
      const posterId = await upsertPoster(batch[i].posterName, batch[i].posterProfileUrl, phones, emails);
      if (posterId) rows[i].poster_id = posterId;

      try {
        const resp = await fetch(`${SUPABASE_URL}/rest/v1/fb_deal_posts`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'apikey': SUPABASE_ANON_KEY,
            'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
            'Prefer': 'return=minimal',
          },
          body: JSON.stringify(rows[i]),
        });

        if (resp.ok || resp.status === 201) {
          batch[i].status = 'synced';
          await dbPut(db, batch[i]);
          synced++;
        } else {
          const errText = await resp.text();
          // Duplicate = UNIQUE constraint on post_hash
          if (errText.includes('duplicate') || errText.includes('unique') || errText.includes('23505')) {
            batch[i].status = 'synced'; // Already in Supabase, mark done
            await dbPut(db, batch[i]);
            dupes++;
          } else {
            batch[i].status = 'error';
            batch[i].syncAttempts++;
            batch[i].syncError = `HTTP ${resp.status}: ${errText.substring(0, 200)}`;
            await dbPut(db, batch[i]);
            errors++;
          }
        }
      } catch (fetchErr) {
        batch[i].status = 'error';
        batch[i].syncAttempts++;
        batch[i].syncError = fetchErr.message;
        await dbPut(db, batch[i]);
        errors++;
      }
      await reportProgress();
    }

    // Clear progress indicator
    await chrome.storage.local.set({
      syncProgress: { current: rows.length, total: rows.length, synced, dupes, errors, active: false }
    });

    db.close();
    await updateBadge();
    console.log(`[FB Deal Scraper] Sync: ${synced} new, ${dupes} dupes, ${errors} errors`);
    return { synced, duplicates: dupes, errors };
  } catch (err) {
    console.error('[FB Deal Scraper] Sync error:', err.message);
    if (db) {
      try {
        const pending = await dbGetAllByStatus(db, ['syncing']);
        for (const record of pending) {
          record.status = 'error';
          record.syncAttempts++;
          record.syncError = err.message;
          await dbPut(db, record);
        }
      } catch (_) { /* best effort */ }
      db.close();
    }
    await updateBadge();
    return { synced: 0, errors: 0 };
  }
}

/* ───────── Stats & Badge ───────── */

async function getQueueStats() {
  const db = await openDb();
  const all = await dbGetAll(db);
  db.close();

  const stats = { queued: 0, syncing: 0, synced: 0, error: 0, total: all.length };
  for (const r of all) {
    if (stats[r.status] !== undefined) stats[r.status]++;
  }
  return stats;
}

async function updateBadge() {
  try {
    const stats = await getQueueStats();
    const pending = stats.queued + stats.error;
    if (pending > 0) {
      chrome.action.setBadgeText({ text: String(pending) });
      chrome.action.setBadgeBackgroundColor({ color: stats.error > 0 ? '#ef4444' : '#f59e0b' });
    } else if (stats.synced > 0) {
      chrome.action.setBadgeText({ text: String(stats.synced) });
      chrome.action.setBadgeBackgroundColor({ color: '#22c55e' });
    } else {
      chrome.action.setBadgeText({ text: '' });
    }
  } catch (_) { /* badge update is best-effort */ }
}

/* ───────── Export ───────── */

async function exportQueue() {
  const db = await openDb();
  const all = await dbGetAllByStatus(db, ['queued', 'error']);
  db.close();
  return all.map(r => ({
    postText: r.postText,
    postHash: r.postHash,
    images: r.images,
    posterName: r.posterName,
    groupName: r.groupName,
    postUrl: r.postUrl,
    collectorName: r.collectorName,
    capturedAt: r.capturedAt,
  }));
}

/* ───────── Clear Synced ───────── */

async function clearSynced() {
  const db = await openDb();
  await dbDeleteByStatus(db, 'synced');
  db.close();
  await updateBadge();
}

/* ───────── Message Handler ───────── */

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'NEW_POST') {
    (async () => {
      try {
        const id = await queuePost(message.data);
        sendResponse({ success: true, queued: true, id });
        // Attempt sync in background (don't block response)
        syncQueue().catch(() => {});
      } catch (err) {
        console.error('[FB Deal Scraper] Queue error:', err.message);
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true; // keep channel open for async
  }

  if (message.type === 'SYNC_NOW') {
    syncQueue()
      .then(result => sendResponse({ success: true, ...result }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }

  if (message.type === 'GET_QUEUE_STATS') {
    getQueueStats()
      .then(stats => sendResponse(stats))
      .catch(err => sendResponse({ error: err.message }));
    return true;
  }

  if (message.type === 'EXPORT_QUEUE') {
    exportQueue()
      .then(data => sendResponse({ success: true, data }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }

  if (message.type === 'CLEAR_SYNCED') {
    clearSynced()
      .then(() => sendResponse({ success: true }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }
});

/* ───────── Alarm for Periodic Sync ───────── */

chrome.alarms.create('sync-queue', { periodInMinutes: 5 });

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'sync-queue') {
    syncQueue().catch(err => {
      console.error('[FB Deal Scraper] Alarm sync failed:', err.message);
    });
  }
});

// Sync on startup
syncQueue().catch(() => {});
