/**
 * FB Deal Scraper — Supabase Configuration
 *
 * Replace these with your actual Supabase project values.
 * The anon key is safe to ship in the extension — Row Level Security
 * on the Supabase table restricts collectors to INSERT only.
 */
export const SUPABASE_URL = 'https://xpvvgecwajqmveuuhnmc.supabase.co';
export const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhwdnZnZWN3YWpxbXZldXVobm1jIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQ0MzgzMTksImV4cCI6MjA5MDAxNDMxOX0.l6KhvXHp3WdltKYtiSfrAHAgRwRxtfh6lZ0B73i0myc';
