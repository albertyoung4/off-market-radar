/**
 * FB Deal Scraper — Content Script
 * Passively captures deal posts as the user scrolls Facebook group feeds.
 * Processes posts immediately to beat Facebook's virtual scroll DOM recycling.
 */

(function () {
  'use strict';

  const DEAL_KEYWORDS = /\$|asking|arv|rehab|sqft|sq\s*ft|bed|bath|bd|ba|yr\s*built|year\s*built|off\s*market|wholesale|investor|end\s*buyer|financing|move.in.ready|fixer|single\s*family|sfr|xxxx/i;
  const seenHashes = new Set();
  const seenElements = new WeakSet();
  let enabled = true;
  let observer = null;
  let scanInterval = null;

  /* ───────── Activity Panel ───────── */
  const MAX_LOG_ENTRIES = 80;
  let panelVisible = true;
  let panelMinimized = false;
  const stats = { captured: 0, skipped: 0, duplicates: 0, errors: 0, queued: 0 };

  function createPanel() {
    const panel = document.createElement('div');
    panel.id = 'fb-deal-panel';
    panel.innerHTML = `
      <div id="fb-deal-panel-header">
        <span id="fb-deal-panel-title">Deal Scraper</span>
        <span id="fb-deal-panel-stats"></span>
        <span id="fb-deal-panel-controls">
          <button id="fb-deal-btn-clear" title="Clear log">&#x1F5D1;</button>
          <button id="fb-deal-btn-min" title="Minimize">&#x2500;</button>
          <button id="fb-deal-btn-close" title="Hide panel">&#x2715;</button>
        </span>
      </div>
      <div id="fb-deal-panel-body">
        <div id="fb-deal-log"></div>
      </div>
    `;
    const style = document.createElement('style');
    style.textContent = `
      #fb-deal-panel {
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        width: 100%;
        max-height: 320px;
        background: #1a1a2e;
        border-top: 2px solid #4ecca3;
        border-radius: 0;
        font-family: 'SF Mono', 'Consolas', 'Monaco', monospace;
        font-size: 11px;
        color: #e0e0e0;
        z-index: 999999;
        box-shadow: 0 -4px 24px rgba(0,0,0,0.4);
        display: flex;
        flex-direction: column;
        overflow: hidden;
        transition: max-height 0.2s ease;
        user-select: none;
      }
      #fb-deal-panel.minimized {
        max-height: 36px;
      }
      #fb-deal-panel.hidden {
        display: none;
      }
      #fb-deal-panel-header {
        display: flex;
        align-items: center;
        padding: 8px 16px;
        background: #16213e;
        cursor: default;
        border-bottom: 1px solid #333;
        flex-shrink: 0;
      }
      #fb-deal-panel-title {
        font-weight: 700;
        color: #4ecca3;
        margin-right: 8px;
        white-space: nowrap;
      }
      #fb-deal-panel-stats {
        flex: 1;
        font-size: 10px;
        color: #888;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      #fb-deal-panel-controls {
        display: flex;
        gap: 4px;
        flex-shrink: 0;
      }
      #fb-deal-panel-controls button {
        background: none;
        border: 1px solid #444;
        color: #aaa;
        cursor: pointer;
        border-radius: 4px;
        width: 22px;
        height: 22px;
        font-size: 12px;
        line-height: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0;
      }
      #fb-deal-panel-controls button:hover {
        background: #333;
        color: #fff;
      }
      #fb-deal-panel-body {
        flex: 1;
        overflow-y: auto;
        padding: 4px 0;
        min-height: 0;
      }
      #fb-deal-panel.minimized #fb-deal-panel-body {
        display: none;
      }
      #fb-deal-log {
        display: flex;
        flex-direction: column;
      }
      .fb-deal-entry {
        padding: 3px 16px;
        border-bottom: 1px solid #222;
        line-height: 1.4;
        word-break: break-word;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .fb-deal-entry:hover {
        background: #222;
        white-space: normal;
      }
      .fb-deal-entry .fb-deal-time {
        color: #555;
        margin-right: 6px;
      }
      .fb-deal-entry.captured { border-left: 3px solid #4ecca3; }
      .fb-deal-entry.skipped { border-left: 3px solid #555; }
      .fb-deal-entry.duplicate { border-left: 3px solid #f0ad4e; }
      .fb-deal-entry.error { border-left: 3px solid #e74c3c; }
      .fb-deal-entry.matched { border-left: 3px solid #22c55e; }
      .fb-deal-entry.multi_match { border-left: 3px solid #eab308; }
      .fb-deal-entry.no_match { border-left: 3px solid #e74c3c; }
      .fb-deal-entry.info { border-left: 3px solid #3b82f6; }
      .fb-deal-tag {
        display: inline-block;
        padding: 1px 5px;
        border-radius: 3px;
        font-size: 9px;
        font-weight: 700;
        text-transform: uppercase;
        margin-right: 4px;
      }
      .fb-deal-tag.captured { background: #0d3320; color: #4ecca3; }
      .fb-deal-tag.skipped { background: #2a2a2a; color: #888; }
      .fb-deal-tag.duplicate { background: #3d2e0a; color: #f0ad4e; }
      .fb-deal-tag.error { background: #3d0a0a; color: #e74c3c; }
      .fb-deal-tag.matched { background: #0a3d1a; color: #22c55e; }
      .fb-deal-tag.multi_match { background: #3d350a; color: #eab308; }
      .fb-deal-tag.no_match { background: #3d0a0a; color: #e74c3c; }
      .fb-deal-tag.info { background: #0a1a3d; color: #3b82f6; }
    `;
    document.head.appendChild(style);
    document.body.appendChild(panel);

    // Buttons
    panel.querySelector('#fb-deal-btn-min').addEventListener('click', () => {
      panelMinimized = !panelMinimized;
      panel.classList.toggle('minimized', panelMinimized);
      panel.querySelector('#fb-deal-btn-min').innerHTML = panelMinimized ? '&#x25A1;' : '&#x2500;';
    });
    panel.querySelector('#fb-deal-btn-close').addEventListener('click', () => {
      panelVisible = false;
      panel.classList.add('hidden');
    });
    panel.querySelector('#fb-deal-btn-clear').addEventListener('click', () => {
      panel.querySelector('#fb-deal-log').innerHTML = '';
    });

    return panel;
  }

  function getTimeStr() {
    const d = new Date();
    return d.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }

  function updateStats() {
    const el = document.getElementById('fb-deal-panel-stats');
    if (!el) return;
    el.textContent = `${stats.captured} captured | ${stats.queued} queued | ${stats.duplicates} dup | ${stats.skipped} skip | ${stats.errors} err`;
  }

  function logEntry(type, message) {
    const log = document.getElementById('fb-deal-log');
    if (!log) return;
    const entry = document.createElement('div');
    entry.className = `fb-deal-entry ${type}`;
    entry.innerHTML = `<span class="fb-deal-time">${getTimeStr()}</span><span class="fb-deal-tag ${type}">${type.replace('_', ' ')}</span>${message}`;
    log.appendChild(entry);
    // Trim old entries
    while (log.children.length > MAX_LOG_ENTRIES) {
      log.removeChild(log.firstChild);
    }
    // Auto-scroll to bottom
    const body = document.getElementById('fb-deal-panel-body');
    if (body) body.scrollTop = body.scrollHeight;
  }

  /* ───────── End Activity Panel ───────── */

  function quickHash(str) {
    let hash = 0;
    const s = str.trim().substring(0, 200);
    for (let i = 0; i < s.length; i++) {
      const char = s.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash |= 0;
    }
    return String(hash);
  }

  function getPostText(postEl) {
    const textDivs = Array.from(postEl.querySelectorAll('div[dir="auto"]'))
      .filter(d => !d.closest('h2, h3, h4, h5'));
    let shallowest = null;
    let minDepth = 999;
    for (const d of textDivs) {
      let depth = 0, n = d;
      while (n !== postEl && n.parentElement) { n = n.parentElement; depth++; }
      const text = d.innerText?.trim();
      if (text && text.length > 20 && depth < minDepth) {
        minDepth = depth;
        shallowest = d;
      }
    }
    return (shallowest?.innerText?.trim() || '').replace(/…?\s*See more\s*$/i, '').trim();
  }

  function getGroupName() {
    const h1 = document.querySelector('h1');
    if (h1) {
      const text = h1.innerText?.trim();
      if (text && text.length > 3 && !/^(Home|Watch|Marketplace|Groups|Gaming|Menu)$/i.test(text)) {
        return text;
      }
    }
    return document.title.replace(/ \| Facebook$/, '').replace(/^\(\d+\+?\)\s*/, '').trim();
  }

  function truncate(str, len) {
    if (!str) return '';
    return str.length > len ? str.substring(0, len) + '...' : str;
  }

  function capturePost(postEl) {
    if (!enabled) return;

    const seeMoreBtn = Array.from(postEl.querySelectorAll('[role="button"]'))
      .find(b => /^See more$/i.test(b.innerText?.trim()));
    if (seeMoreBtn) {
      seeMoreBtn.click();
    }

    const postText = getPostText(postEl);
    if (!postText || postText.length < 30) {
      stats.skipped++;
      updateStats();
      logEntry('skipped', `Too short (${postText?.length || 0} chars)`);
      return;
    }
    if (!DEAL_KEYWORDS.test(postText)) {
      stats.skipped++;
      updateStats();
      logEntry('skipped', `No keywords: "${truncate(postText, 60)}"`);
      return;
    }

    const hash = quickHash(postText);
    if (seenHashes.has(hash)) {
      logEntry('skipped', `Already seen (hash dedup)`);
      return;
    }
    seenHashes.add(hash);

    let posterName = '';
    let posterProfileUrl = '';
    const heading = postEl.querySelector('h2, h3, h4');
    if (heading) {
      posterName = heading.innerText?.trim() || '';
      const profileLink = heading.querySelector('a[href*="facebook.com/"]') ||
        heading.parentElement?.querySelector('a[href*="facebook.com/"]');
      if (profileLink) posterProfileUrl = profileLink.href;
    }
    // Fallback: look for strong/bold name links near the top of the post
    if (!posterName) {
      const nameLink = postEl.querySelector('a[role="link"] > strong, a[role="link"] > span > strong');
      if (nameLink) {
        posterName = nameLink.innerText?.trim() || '';
        const parentLink = nameLink.closest('a[href*="facebook.com/"]');
        if (parentLink && !posterProfileUrl) posterProfileUrl = parentLink.href;
      }
    }
    // Last resort: any profile-style link at the top of the card
    if (!posterProfileUrl) {
      const topLinks = postEl.querySelectorAll('a[href*="facebook.com/"][role="link"]');
      for (const link of topLinks) {
        const href = link.href || '';
        // Skip non-profile links (photos, posts, groups, hashtags)
        if (/\/(photo|posts|permalink|groups|hashtag|watch|reel|story)/i.test(href)) continue;
        if (href.includes('/user/') || /facebook\.com\/[a-zA-Z0-9.]+\/?(\?|$)/.test(href)) {
          posterProfileUrl = href;
          if (!posterName) posterName = link.innerText?.trim() || '';
          break;
        }
      }
    }

    const images = [];
    for (const img of postEl.querySelectorAll('img[src*="scontent"]')) {
      if (img.naturalWidth > 100 || img.width > 100) {
        images.push(img.src);
      }
    }

    let postUrl = '';
    // Facebook uses many URL patterns for group posts — try all known variants
    const urlLinkEl = postEl.querySelector(
      'a[href*="/posts/"], a[href*="/permalink/"], a[href*="story_fbid"], a[href*="/p/"], a[href*="pcb."]'
    );
    if (urlLinkEl) {
      postUrl = urlLinkEl.href;
    } else {
      // Fallback: find the timestamp link (usually the permalink) near the poster heading
      const heading = postEl.querySelector('h2, h3, h4');
      if (heading) {
        // The timestamp link is typically a sibling or nearby element after the heading
        const parent = heading.closest('[data-ad-preview], [data-ad-comet-preview]')?.parentElement || heading.parentElement?.parentElement;
        if (parent) {
          const tsLink = parent.querySelector('a[href*="facebook.com"][role="link"]');
          if (tsLink && tsLink.href && !tsLink.href.includes('/photo') && !tsLink.href.includes('/user/')) {
            postUrl = tsLink.href;
          }
        }
      }
    }

    // Extract post timestamp from Facebook DOM.
    // Modern FB puts the best human-readable date in aria-label on the permalink <a>.
    // e.g. aria-label="March 25, 2026 at 10:00 AM" or "Yesterday at 3:15 PM"
    let postTimestamp = '';
    // Timestamp pattern: must contain a time-like pattern (digits with : or /) or relative keywords
    // "may" excluded as standalone to avoid matching "May be an image of..." aria-labels
    const TS_PATTERN = /\d{1,2}[:/]\d{2}|\d+\s*(?:h|m|hr|min|sec)\b|ago|hour|minute|yesterday|monday|tuesday|wednesday|thursday|friday|saturday|sunday|january|february|march|april|june|july|august|september|october|november|december/i;
    const TS_MAY_DATE = /may\s+\d/i; // "May 25" is a date, "May be an image" is not

    function isTimestampLabel(label) {
      if (!label) return false;
      if (TS_PATTERN.test(label)) return true;
      if (TS_MAY_DATE.test(label)) return true;
      return false;
    }

    // 1. Best: aria-label on the permalink/posts link (most readable, often full date)
    const tsAnchor = postEl.querySelector('a[href*="/posts/"][aria-label], a[href*="/permalink/"][aria-label], a[href*="story_fbid"][aria-label], a[href*="/p/"][aria-label]');
    if (tsAnchor) {
      const label = tsAnchor.getAttribute('aria-label');
      if (isTimestampLabel(label)) postTimestamp = label;
    }

    // 2. <time datetime="..."> — ISO string (reliable when present)
    if (!postTimestamp) {
      const timeEl = postEl.querySelector('time[datetime]');
      if (timeEl) postTimestamp = timeEl.getAttribute('datetime') || '';
    }

    // 3. <abbr data-utime="..."> — Unix epoch (older FB markup)
    if (!postTimestamp) {
      const abbrEl = postEl.querySelector('abbr[data-utime]');
      if (abbrEl?.dataset.utime) {
        postTimestamp = new Date(Number(abbrEl.dataset.utime) * 1000).toISOString();
      }
    }

    // 4. Visible relative time text inside the permalink span ("2h", "Yesterday at 3:15 PM")
    if (!postTimestamp) {
      const tsSpan = postEl.querySelector('a[href*="/posts/"] span, a[href*="/permalink/"] span, a[href*="story_fbid"] span, a[href*="/p/"] span');
      const tsText = tsSpan?.innerText?.trim();
      if (tsText && /\d/.test(tsText)) postTimestamp = tsText;
    }

    // 5. Any aria-label on any link that looks like a timestamp (skip image alt-text)
    if (!postTimestamp) {
      for (const al of postEl.querySelectorAll('a[aria-label]')) {
        const label = al.getAttribute('aria-label');
        if (label && label.startsWith('May be')) continue; // skip image descriptions
        if (isTimestampLabel(label)) { postTimestamp = label; break; }
      }
    }

    const data = {
      postText,
      images,
      posterName,
      posterProfileUrl,
      timestamp: postTimestamp,
      postUrl,
      groupName: getGroupName(),
    };

    const preview = truncate(postText, 70);
    logEntry('captured', `<b>${posterName || '?'}</b>: "${preview}"`);
    stats.captured++;
    updateStats();

    chrome.runtime.sendMessage({ type: 'NEW_POST', data }, (response) => {
      if (chrome.runtime.lastError) {
        stats.errors++;
        updateStats();
        logEntry('error', `Send failed: ${chrome.runtime.lastError.message}`);
        return;
      }
      if (response?.success && response.queued) {
        stats.queued++;
        updateStats();
        logEntry('info', `Queued for sync`);
      } else if (response && !response.success) {
        stats.errors++;
        updateStats();
        logEntry('error', response.error || 'Queue failed');
      }
    });

    // Re-capture expanded text
    if (seeMoreBtn) {
      setTimeout(() => {
        const expandedText = getPostText(postEl);
        if (expandedText && expandedText.length > postText.length + 20) {
          const expandedHash = quickHash(expandedText);
          if (!seenHashes.has(expandedHash)) {
            seenHashes.add(expandedHash);
            data.postText = expandedText;
            logEntry('info', `Re-captured expanded (+${expandedText.length - postText.length} chars)`);
            chrome.runtime.sendMessage({ type: 'NEW_POST', data }, () => {});
          }
        }
      }, 800);
    }
  }

  function maybeCapture(el) {
    if (!el || el.children.length === 0) return;
    if (seenElements.has(el)) return;
    const textDiv = el.querySelector('div[dir="auto"]');
    if (!textDiv || textDiv.innerText?.trim().length <= 10) return;
    seenElements.add(el);
    capturePost(el);
  }

  function getFeed() {
    return document.querySelector('[role="feed"]');
  }

  function scanFeed() {
    const feed = getFeed();
    if (!feed) return;
    for (const child of feed.children) {
      maybeCapture(child);
    }
  }

  function startObserving() {
    scanFeed();

    observer = new MutationObserver((mutations) => {
      const feed = getFeed();
      if (!feed) return;
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          if (node.nodeType !== 1) continue;
          if (node.parentElement === feed) {
            maybeCapture(node);
          }
          if (node.querySelector?.('[role="feed"]')) {
            scanFeed();
          }
        }
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
    });

    scanInterval = setInterval(() => {
      if (enabled) scanFeed();
    }, 1500);

    logEntry('info', 'Observing for deal posts...');
    console.log('[FB Deal Scraper] Observing for deal posts...');
  }

  function stopObserving() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
    if (scanInterval) {
      clearInterval(scanInterval);
      scanInterval = null;
    }
    logEntry('info', 'Stopped observing.');
    console.log('[FB Deal Scraper] Stopped observing.');
  }

  // Listen for toggle messages from popup
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'TOGGLE') {
      // Check collector name before enabling
      chrome.storage.local.get(['collectorName'], (result) => {
        const hasName = result.collectorName && result.collectorName.trim().length > 0;
        if (msg.enabled && !hasName) {
          enabled = false;
          logEntry('warn', 'Cannot enable — set your Collector Name in the extension popup first.');
          sendResponse({ enabled: false, error: 'name_required' });
          return;
        }
        enabled = msg.enabled;
        if (enabled) startObserving();
        else stopObserving();
        sendResponse({ enabled });
      });
      return true; // async sendResponse
    }
    if (msg.type === 'GET_STATUS') {
      sendResponse({ enabled, seenCount: seenHashes.size });
    }
    if (msg.type === 'TOGGLE_PANEL') {
      const panel = document.getElementById('fb-deal-panel');
      if (panel) {
        panelVisible = !panelVisible;
        panel.classList.toggle('hidden', !panelVisible);
      }
      sendResponse({ panelVisible });
    }
  });

  // Start
  chrome.storage.local.get(['enabled', 'collectorName'], (result) => {
    const hasName = result.collectorName && result.collectorName.trim().length > 0;
    enabled = hasName && result.enabled !== false;
    // Create the activity panel
    createPanel();
    if (!hasName) {
      logEntry('warn', 'Scraping disabled — set your Collector Name in the extension popup first.');
    } else {
      logEntry('info', `Extension loaded. Collector: ${result.collectorName}. Enabled: ${enabled}`);
    }
    updateStats();

    if (enabled) {
      if (getFeed()) {
        startObserving();
      } else {
        logEntry('info', 'Waiting for feed to appear...');
        const waitForFeed = setInterval(() => {
          if (getFeed()) {
            clearInterval(waitForFeed);
            startObserving();
          }
        }, 1000);
        setTimeout(() => clearInterval(waitForFeed), 30000);
      }
    }
  });
})();
