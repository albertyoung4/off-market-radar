/**
 * FB Deal Scraper — Content Script
 * Passively captures deal posts as the user scrolls Facebook group feeds.
 * Processes posts immediately to beat Facebook's virtual scroll DOM recycling.
 */

(function () {
  'use strict';

  const DEAL_KEYWORDS = /\$|asking|arv|rehab|sqft|sq\s*ft|bed|bath|bd|ba|yr\s*built|year\s*built|off\s*market|wholesale|investor|end\s*buyer|financing|move.in.ready|fixer|single\s*family|sfr|xxxx/i;
  const seenHashes = new Set();
  const seenElements = new WeakSet();
  let enabled = true;
  let observer = null;
  let scanInterval = null;

  /* ───────── Activity Panel ───────── */
  const MAX_LOG_ENTRIES = 80;
  let panelVisible = true;
  let panelMinimized = false;
  const stats = { captured: 0, skipped: 0, duplicates: 0, errors: 0, queued: 0 };

  function createPanel() {
    const panel = document.createElement('div');
    panel.id = 'fb-deal-panel';
    panel.innerHTML = `
      <div id="fb-deal-panel-header">
        <span id="fb-deal-panel-title">Deal Scraper</span>
        <span id="fb-deal-panel-stats"></span>
        <span id="fb-deal-panel-controls">
          <button id="fb-deal-btn-clear" title="Clear log">&#x1F5D1;</button>
          <button id="fb-deal-btn-min" title="Minimize">&#x2500;</button>
          <button id="fb-deal-btn-close" title="Hide panel">&#x2715;</button>
        </span>
      </div>
      <div id="fb-deal-panel-body">
        <div id="fb-deal-log"></div>
      </div>
    `;
    const style = document.createElement('style');
    style.textContent = `
      #fb-deal-panel {
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        width: 100%;
        max-height: 320px;
        background: #1a1a2e;
        border-top: 2px solid #4ecca3;
        border-radius: 0;
        font-family: 'SF Mono', 'Consolas', 'Monaco', monospace;
        font-size: 11px;
        color: #e0e0e0;
        z-index: 999999;
        box-shadow: 0 -4px 24px rgba(0,0,0,0.4);
        display: flex;
        flex-direction: column;
        overflow: hidden;
        transition: max-height 0.2s ease;
        user-select: none;
      }
      #fb-deal-panel.minimized {
        max-height: 36px;
      }
      #fb-deal-panel.hidden {
        display: none;
      }
      #fb-deal-panel-header {
        display: flex;
        align-items: center;
        padding: 8px 16px;
        background: #16213e;
        cursor: default;
        border-bottom: 1px solid #333;
        flex-shrink: 0;
      }
      #fb-deal-panel-title {
        font-weight: 700;
        color: #4ecca3;
        margin-right: 8px;
        white-space: nowrap;
      }
      #fb-deal-panel-stats {
        flex: 1;
        font-size: 10px;
        color: #888;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      #fb-deal-panel-controls {
        display: flex;
        gap: 4px;
        flex-shrink: 0;
      }
      #fb-deal-panel-controls button {
        background: none;
        border: 1px solid #444;
        color: #aaa;
        cursor: pointer;
        border-radius: 4px;
        width: 22px;
        height: 22px;
        font-size: 12px;
        line-height: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0;
      }
      #fb-deal-panel-controls button:hover {
        background: #333;
        color: #fff;
      }
      #fb-deal-panel-body {
        flex: 1;
        overflow-y: auto;
        padding: 4px 0;
        min-height: 0;
      }
      #fb-deal-panel.minimized #fb-deal-panel-body {
        display: none;
      }
      #fb-deal-log {
        display: flex;
        flex-direction: column;
      }
      .fb-deal-entry {
        padding: 3px 16px;
        border-bottom: 1px solid #222;
        line-height: 1.4;
        word-break: break-word;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .fb-deal-entry:hover {
        background: #222;
        white-space: normal;
      }
      .fb-deal-entry .fb-deal-time {
        color: #555;
        margin-right: 6px;
      }
      .fb-deal-entry.captured { border-left: 3px solid #4ecca3; }
      .fb-deal-entry.skipped { border-left: 3px solid #555; }
      .fb-deal-entry.duplicate { border-left: 3px solid #f0ad4e; }
      .fb-deal-entry.error { border-left: 3px solid #e74c3c; }
      .fb-deal-entry.matched { border-left: 3px solid #22c55e; }
      .fb-deal-entry.multi_match { border-left: 3px solid #eab308; }
      .fb-deal-entry.no_match { border-left: 3px solid #e74c3c; }
      .fb-deal-entry.info { border-left: 3px solid #3b82f6; }
      .fb-deal-tag {
        display: inline-block;
        padding: 1px 5px;
        border-radius: 3px;
        font-size: 9px;
        font-weight: 700;
        text-transform: uppercase;
        margin-right: 4px;
      }
      .fb-deal-tag.captured { background: #0d3320; color: #4ecca3; }
      .fb-deal-tag.skipped { background: #2a2a2a; color: #888; }
      .fb-deal-tag.duplicate { background: #3d2e0a; color: #f0ad4e; }
      .fb-deal-tag.error { background: #3d0a0a; color: #e74c3c; }
      .fb-deal-tag.matched { background: #0a3d1a; color: #22c55e; }
      .fb-deal-tag.multi_match { background: #3d350a; color: #eab308; }
      .fb-deal-tag.no_match { background: #3d0a0a; color: #e74c3c; }
      .fb-deal-tag.info { background: #0a1a3d; color: #3b82f6; }
    `;
    document.head.appendChild(style);
    document.body.appendChild(panel);

    // Buttons
    panel.querySelector('#fb-deal-btn-min').addEventListener('click', () => {
      panelMinimized = !panelMinimized;
      panel.classList.toggle('minimized', panelMinimized);
      panel.querySelector('#fb-deal-btn-min').innerHTML = panelMinimized ? '&#x25A1;' : '&#x2500;';
    });
    panel.querySelector('#fb-deal-btn-close').addEventListener('click', () => {
      panelVisible = false;
      panel.classList.add('hidden');
    });
    panel.querySelector('#fb-deal-btn-clear').addEventListener('click', () => {
      panel.querySelector('#fb-deal-log').innerHTML = '';
    });

    return panel;
  }

  function getTimeStr() {
    const d = new Date();
    return d.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }

  function updateStats() {
    const el = document.getElementById('fb-deal-panel-stats');
    if (!el) return;
    el.textContent = `${stats.captured} captured | ${stats.queued} queued | ${stats.duplicates} dup | ${stats.skipped} skip | ${stats.errors} err`;
  }

  function logEntry(type, message) {
    const log = document.getElementById('fb-deal-log');
    if (!log) return;
    const entry = document.createElement('div');
    entry.className = `fb-deal-entry ${type}`;
    entry.innerHTML = `<span class="fb-deal-time">${getTimeStr()}</span><span class="fb-deal-tag ${type}">${type.replace('_', ' ')}</span>${message}`;
    log.appendChild(entry);
    // Trim old entries
    while (log.children.length > MAX_LOG_ENTRIES) {
      log.removeChild(log.firstChild);
    }
    // Auto-scroll to bottom
    const body = document.getElementById('fb-deal-panel-body');
    if (body) body.scrollTop = body.scrollHeight;
  }

  /* ───────── End Activity Panel ───────── */

  function quickHash(str) {
    let hash = 0;
    const s = str.trim().substring(0, 200);
    for (let i = 0; i < s.length; i++) {
      const char = s.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash |= 0;
    }
    return String(hash);
  }

  function getPostText(postEl) {
    const textDivs = Array.from(postEl.querySelectorAll('div[dir="auto"]'))
      .filter(d => !d.closest('h2, h3, h4, h5'));
    let shallowest = null;
    let minDepth = 999;
    for (const d of textDivs) {
      let depth = 0, n = d;
      while (n !== postEl && n.parentElement) { n = n.parentElement; depth++; }
      const text = d.innerText?.trim();
      if (text && text.length > 20 && depth < minDepth) {
        minDepth = depth;
        shallowest = d;
      }
    }
    return (shallowest?.innerText?.trim() || '').replace(/…?\s*See more\s*$/i, '').trim();
  }

  function getGroupName() {
    // Facebook can have multiple <h1> elements (e.g. "Chats" sidebar + group name).
    // Filter out known non-group names and pick the best match.
    const skipNames = /^(Home|Watch|Marketplace|Groups|Gaming|Menu|Chats|Notifications|Friends|Memories|Saved|Events|Pages|Ads Manager|Meta Business Suite)$/i;
    const allH1s = document.querySelectorAll('h1');
    for (const h1 of allH1s) {
      const text = h1.innerText?.trim();
      if (text && text.length > 3 && !skipNames.test(text)) {
        return text;
      }
    }
    return document.title.replace(/ \| Facebook$/, '').replace(/^\(\d+\+?\)\s*/, '').trim();
  }

  function truncate(str, len) {
    if (!str) return '';
    return str.length > len ? str.substring(0, len) + '...' : str;
  }

  function capturePost(postEl) {
    if (!enabled) return;

    const seeMoreBtn = Array.from(postEl.querySelectorAll('[role="button"]'))
      .find(b => /^See more$/i.test(b.innerText?.trim()));
    if (seeMoreBtn) {
      seeMoreBtn.click();
    }

    const postText = getPostText(postEl);
    if (!postText || postText.length < 30) {
      stats.skipped++;
      updateStats();
      logEntry('skipped', `Too short (${postText?.length || 0} chars)`);
      return;
    }
    if (!DEAL_KEYWORDS.test(postText)) {
      stats.skipped++;
      updateStats();
      logEntry('skipped', `No keywords: "${truncate(postText, 60)}"`);
      return;
    }

    const hash = quickHash(postText);
    if (seenHashes.has(hash)) {
      logEntry('skipped', `Already seen (hash dedup)`);
      return;
    }
    seenHashes.add(hash);

    let posterName = '';
    let posterProfileUrl = '';
    const heading = postEl.querySelector('h2, h3, h4');
    if (heading) {
      posterName = (heading.innerText?.trim() || '')
        .replace(/\s*[\n\r]+\s*/g, ' ')           // collapse newlines
        .replace(/\s*·\s*Follow\s*/gi, '')          // remove "· Follow"
        .replace(/\s*·\s*Suggested for you\s*/gi, '') // remove suggested
        .replace(/\s+/g, ' ')                       // normalize spaces
        .trim();
      const profileLink = heading.querySelector('a[href*="facebook.com/"]') ||
        heading.parentElement?.querySelector('a[href*="facebook.com/"]');
      if (profileLink) posterProfileUrl = profileLink.href;
    }
    // Fallback: look for strong/bold name links near the top of the post
    if (!posterName) {
      const nameLink = postEl.querySelector('a[role="link"] > strong, a[role="link"] > span > strong');
      if (nameLink) {
        posterName = nameLink.innerText?.trim() || '';
        const parentLink = nameLink.closest('a[href*="facebook.com/"]');
        if (parentLink && !posterProfileUrl) posterProfileUrl = parentLink.href;
      }
    }
    // Last resort: any profile-style link at the top of the card
    if (!posterProfileUrl) {
      const topLinks = postEl.querySelectorAll('a[href*="facebook.com/"][role="link"]');
      for (const link of topLinks) {
        const href = link.href || '';
        // Skip non-profile links (photos, posts, groups, hashtags)
        if (/\/(photo|posts|permalink|groups|hashtag|watch|reel|story)/i.test(href)) continue;
        if (href.includes('/user/') || /facebook\.com\/[a-zA-Z0-9.]+\/?(\?|$)/.test(href)) {
          posterProfileUrl = href;
          if (!posterName) posterName = link.innerText?.trim() || '';
          break;
        }
      }
    }

    const images = [];
    for (const img of postEl.querySelectorAll('img[src*="scontent"]')) {
      if (img.naturalWidth > 100 || img.width > 100) {
        images.push(img.src);
      }
    }

    let postUrl = '';
    // Facebook uses many URL patterns for group posts — try all known variants
    const urlLinkEl = postEl.querySelector(
      'a[href*="/posts/"], a[href*="/permalink/"], a[href*="story_fbid"], a[href*="/p/"], a[href*="pcb."]'
    );
    if (urlLinkEl) {
      postUrl = urlLinkEl.href;
    } else {
      // Fallback: find the timestamp link (usually the permalink) near the poster heading
      const heading = postEl.querySelector('h2, h3, h4');
      if (heading) {
        // The timestamp link is typically a sibling or nearby element after the heading
        const parent = heading.closest('[data-ad-preview], [data-ad-comet-preview]')?.parentElement || heading.parentElement?.parentElement;
        if (parent) {
          const tsLink = parent.querySelector('a[href*="facebook.com"][role="link"]');
          if (tsLink && tsLink.href && !tsLink.href.includes('/photo') && !tsLink.href.includes('/user/')) {
            postUrl = tsLink.href;
          }
        }
      }
    }

    // Extract post timestamp from Facebook DOM.
    let postTimestamp = '';

    // Strict timestamp patterns — require date-like structure, not just month names
    function isTimestampLabel(label) {
      if (!label || label.length > 120) return false;
      if (/^May be\b/i.test(label)) return false;
      if (/image of|photo of|picture of/i.test(label)) return false;
      if (/\d{1,2}:\d{2}/.test(label)) return true;                          // "3:15 PM"
      if (/^\d+\s*(?:h|m|hr|min|sec|d)\s*$/i.test(label)) return true;       // "2h", "45m", "3d"
      if (/\d+\s*(?:hours?|minutes?|seconds?|days?|weeks?)\s*ago/i.test(label)) return true;
      if (/^yesterday/i.test(label)) return true;
      if (/^just now$/i.test(label)) return true;
      if (/(?:january|february|march|april|may|june|july|august|september|october|november|december)\s+\d{1,2}/i.test(label)) return true;
      if (/\d{1,2}\/\d{1,2}\/\d{2,4}/.test(label)) return true;
      if (/(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday)\s+at\s+\d/i.test(label)) return true;
      return false;
    }

    /**
     * Decode Facebook's anti-scrape scrambled timestamp text.
     * FB renders timestamps using a flex container with ~60 absolutely-positioned single-character
     * spans. Real characters use standard FB utility CSS classes (x-prefixed). Noise/decoy characters
     * have extra non-x-prefixed obfuscation classes. We filter to real chars and sort by position.
     */
    function decodeScrambledTimestamp(link) {
      try {
        // Find the overflow:hidden container that clips to visible width
        const overflowContainer = Array.from(link.querySelectorAll('span')).find(s => {
          const cs = window.getComputedStyle(s);
          return cs.overflow === 'hidden' && cs.display === 'inline-block';
        });
        if (!overflowContainer) return null;

        // Find the flex container with many child spans
        const flexContainer = Array.from(link.querySelectorAll('span')).find(s => {
          const cs = window.getComputedStyle(s);
          return cs.display === 'flex' && s.children.length > 10;
        });
        if (!flexContainer) return null;

        // Get all single-character leaf spans
        const charSpans = Array.from(flexContainer.children).filter(
          s => s.children.length === 0 && s.textContent.length === 1
        );
        if (charSpans.length < 2) return null;

        // Real chars: only standard FB utility classes (all start with "x").
        // Noise chars: have additional non-x-prefixed obfuscation classes (7+ of them).
        const realChars = charSpans.filter(s => {
          const classes = s.className.split(/\s+/);
          const nonXCount = classes.filter(c => c && !c.startsWith('x')).length;
          return nonXCount <= 1; // real chars have 0-1 non-x classes; noise has 5+
        });

        if (realChars.length === 0) return null;

        // Sort real chars by their visual position (getBoundingClientRect)
        const fRect = flexContainer.getBoundingClientRect();
        const sorted = realChars.map(s => {
          const rect = s.getBoundingClientRect();
          return { char: s.textContent, left: rect.left - fRect.left };
        }).sort((a, b) => a.left - b.left);

        return sorted.map(c => c.char).join('');
      } catch (e) {
        return null;
      }
    }

    // 1. <time datetime="..."> — ISO string (most reliable when present)
    {
      const timeEl = postEl.querySelector('time[datetime]');
      if (timeEl) postTimestamp = timeEl.getAttribute('datetime') || '';
    }

    // 2. <abbr data-utime="..."> — Unix epoch (older FB markup)
    if (!postTimestamp) {
      const abbrEl = postEl.querySelector('abbr[data-utime]');
      if (abbrEl?.dataset.utime) {
        postTimestamp = new Date(Number(abbrEl.dataset.utime) * 1000).toISOString();
      }
    }

    // 3. aria-label on permalink links
    if (!postTimestamp) {
      const tsAnchor = postEl.querySelector('a[href*="/posts/"][aria-label], a[href*="/permalink/"][aria-label], a[href*="story_fbid"][aria-label], a[href*="/p/"][aria-label]');
      if (tsAnchor) {
        const label = tsAnchor.getAttribute('aria-label');
        if (isTimestampLabel(label)) postTimestamp = label;
      }
    }

    // 4. Visible text in permalink link (groups with slug-style URLs)
    if (!postTimestamp) {
      const tsLink = postEl.querySelector('a[href*="/posts/"], a[href*="/permalink/"], a[href*="story_fbid"], a[href*="/p/"]');
      if (tsLink) {
        const tsText = tsLink.innerText?.trim();
        if (tsText && isTimestampLabel(tsText)) postTimestamp = tsText;
      }
    }

    // 5. Decode scrambled timestamp from group link with CSS-obfuscated chars
    //    Facebook anti-scrape: renders timestamp as 60+ single-char <span>s with noise chars
    //    hidden via CSS positioning. Real chars have standard x-prefixed classes only.
    if (!postTimestamp) {
      const groupLinks = postEl.querySelectorAll('a[href]');
      for (const link of groupLinks) {
        // Look for the scrambled timestamp link: points to group URL, has many child spans
        try {
          const path = new URL(link.href).pathname;
          if (!path.match(/^\/groups\/[^/]+\/?$/)) continue;
        } catch (e) { continue; }
        if (link.querySelectorAll('span').length < 10) continue;

        const decoded = decodeScrambledTimestamp(link);
        if (decoded && isTimestampLabel(decoded)) {
          postTimestamp = decoded;
          break;
        }
      }
    }

    // 6. Fallback: scan aria-labels on post-specific links
    if (!postTimestamp) {
      for (const al of postEl.querySelectorAll('a[aria-label][href*="/posts/"], a[aria-label][href*="/permalink/"], a[aria-label][href*="story_fbid"]')) {
        const label = al.getAttribute('aria-label');
        if (isTimestampLabel(label)) { postTimestamp = label; break; }
      }
    }

    // Log what we found
    if (postTimestamp) {
      logEntry('info', `⏱ TS: "${truncate(postTimestamp, 50)}"`);
    }

    // Convert relative timestamps ("42m", "2h", "3d", "Yesterday at 3:15 PM") to ISO date
    if (postTimestamp && !/^\d{4}-\d{2}/.test(postTimestamp)) {
      try {
        const now = new Date();
        const ts = postTimestamp.toLowerCase().trim();
        let resolved = null;

        // "42m" or "42 min" or "42 minutes ago"
        const minMatch = ts.match(/^(\d+)\s*(?:m|min|minutes?)(?:\s*ago)?$/);
        if (minMatch) resolved = new Date(now - parseInt(minMatch[1]) * 60000);

        // "2h" or "2 hr" or "2 hours ago"
        const hrMatch = ts.match(/^(\d+)\s*(?:h|hr|hours?)(?:\s*ago)?$/);
        if (hrMatch) resolved = new Date(now - parseInt(hrMatch[1]) * 3600000);

        // "3d" or "3 days ago"
        const dayMatch = ts.match(/^(\d+)\s*(?:d|days?)(?:\s*ago)?$/);
        if (dayMatch) resolved = new Date(now - parseInt(dayMatch[1]) * 86400000);

        // "yesterday"
        if (/^yesterday/i.test(ts)) {
          resolved = new Date(now - 86400000);
          // Try to parse time: "Yesterday at 3:15 PM"
          const timeMatch = ts.match(/(\d{1,2}):(\d{2})\s*(am|pm)/i);
          if (timeMatch && resolved) {
            let h = parseInt(timeMatch[1]);
            if (timeMatch[3].toLowerCase() === 'pm' && h !== 12) h += 12;
            if (timeMatch[3].toLowerCase() === 'am' && h === 12) h = 0;
            resolved.setHours(h, parseInt(timeMatch[2]), 0, 0);
          }
        }

        // "just now"
        if (/^just now$/i.test(ts)) resolved = now;

        // "Monday at 3:15 PM" etc
        const dayOfWeek = ['sunday','monday','tuesday','wednesday','thursday','friday','saturday'];
        for (let di = 0; di < dayOfWeek.length; di++) {
          if (ts.startsWith(dayOfWeek[di])) {
            const diff = (now.getDay() - di + 7) % 7 || 7;
            resolved = new Date(now - diff * 86400000);
            const twm = ts.match(/(\d{1,2}):(\d{2})\s*(am|pm)/i);
            if (twm && resolved) {
              let h = parseInt(twm[1]);
              if (twm[3].toLowerCase() === 'pm' && h !== 12) h += 12;
              if (twm[3].toLowerCase() === 'am' && h === 12) h = 0;
              resolved.setHours(h, parseInt(twm[2]), 0, 0);
            }
            break;
          }
        }

        // "March 23 at 8:59 PM" or "March 23, 2026" or "December 8, 2025"
        if (!resolved) {
          const monthNames = { january: 0, february: 1, march: 2, april: 3, may: 4, june: 5, july: 6, august: 7, september: 8, october: 9, november: 10, december: 11 };
          const dateMatch = ts.match(/^(january|february|march|april|may|june|july|august|september|october|november|december)\s+(\d{1,2})(?:,?\s*(\d{4}))?/i);
          if (dateMatch) {
            const month = monthNames[dateMatch[1].toLowerCase()];
            const day = parseInt(dateMatch[2]);
            const year = dateMatch[3] ? parseInt(dateMatch[3]) : now.getFullYear();
            resolved = new Date(year, month, day);
            // Try to parse time: "at 8:59 PM"
            const timeMatch = ts.match(/(\d{1,2}):(\d{2})\s*(am|pm)/i);
            if (timeMatch) {
              let h = parseInt(timeMatch[1]);
              if (timeMatch[3].toLowerCase() === 'pm' && h !== 12) h += 12;
              if (timeMatch[3].toLowerCase() === 'am' && h === 12) h = 0;
              resolved.setHours(h, parseInt(timeMatch[2]), 0, 0);
            }
          }
        }

        // "3/25/2026" or "03/25/26"
        if (!resolved) {
          const slashMatch = ts.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/);
          if (slashMatch) {
            let year = parseInt(slashMatch[3]);
            if (year < 100) year += 2000;
            resolved = new Date(year, parseInt(slashMatch[1]) - 1, parseInt(slashMatch[2]));
          }
        }

        if (resolved && !isNaN(resolved.getTime())) {
          postTimestamp = resolved.toISOString();
        }
      } catch (e) {
        // Keep the raw string if conversion fails
      }
    }

    const data = {
      postText,
      images,
      posterName,
      posterProfileUrl,
      timestamp: postTimestamp,
      postUrl,
      groupName: getGroupName(),
    };

    const preview = truncate(postText, 70);
    logEntry('captured', `<b>${posterName || '?'}</b>: "${preview}"`);
    stats.captured++;
    updateStats();

    chrome.runtime.sendMessage({ type: 'NEW_POST', data }, (response) => {
      if (chrome.runtime.lastError) {
        stats.errors++;
        updateStats();
        logEntry('error', `Send failed: ${chrome.runtime.lastError.message}`);
        return;
      }
      if (response?.success && response.queued) {
        stats.queued++;
        updateStats();
        logEntry('info', `Queued for sync`);
      } else if (response && !response.success) {
        stats.errors++;
        updateStats();
        logEntry('error', response.error || 'Queue failed');
      }
    });

    // Re-capture expanded text
    if (seeMoreBtn) {
      setTimeout(() => {
        const expandedText = getPostText(postEl);
        if (expandedText && expandedText.length > postText.length + 20) {
          const expandedHash = quickHash(expandedText);
          if (!seenHashes.has(expandedHash)) {
            seenHashes.add(expandedHash);
            data.postText = expandedText;
            logEntry('info', `Re-captured expanded (+${expandedText.length - postText.length} chars)`);
            chrome.runtime.sendMessage({ type: 'NEW_POST', data }, () => {});
          }
        }
      }, 800);
    }
  }

  function maybeCapture(el) {
    if (!el || el.children.length === 0) return;
    if (seenElements.has(el)) return;
    const textDiv = el.querySelector('div[dir="auto"]');
    if (!textDiv || textDiv.innerText?.trim().length <= 10) return;
    seenElements.add(el);
    capturePost(el);
  }

  function getFeed() {
    return document.querySelector('[role="feed"]');
  }

  function scanFeed() {
    const feed = getFeed();
    if (!feed) return;
    for (const child of feed.children) {
      maybeCapture(child);
    }
  }

  function startObserving() {
    scanFeed();

    observer = new MutationObserver((mutations) => {
      const feed = getFeed();
      if (!feed) return;
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          if (node.nodeType !== 1) continue;
          if (node.parentElement === feed) {
            maybeCapture(node);
          }
          if (node.querySelector?.('[role="feed"]')) {
            scanFeed();
          }
        }
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
    });

    scanInterval = setInterval(() => {
      if (enabled) scanFeed();
    }, 1500);

    logEntry('info', 'Observing for deal posts...');
    console.log('[FB Deal Scraper] Observing for deal posts...');
  }

  function stopObserving() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
    if (scanInterval) {
      clearInterval(scanInterval);
      scanInterval = null;
    }
    logEntry('info', 'Stopped observing.');
    console.log('[FB Deal Scraper] Stopped observing.');
  }

  // Listen for toggle messages from popup
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'TOGGLE') {
      // Check collector name before enabling
      chrome.storage.local.get(['collectorName'], (result) => {
        const hasName = result.collectorName && result.collectorName.trim().length > 0;
        if (msg.enabled && !hasName) {
          enabled = false;
          logEntry('warn', 'Cannot enable — set your Collector Name in the extension popup first.');
          sendResponse({ enabled: false, error: 'name_required' });
          return;
        }
        enabled = msg.enabled;
        if (enabled) startObserving();
        else stopObserving();
        sendResponse({ enabled });
      });
      return true; // async sendResponse
    }
    if (msg.type === 'GET_STATUS') {
      sendResponse({ enabled, seenCount: seenHashes.size });
    }
    if (msg.type === 'TOGGLE_PANEL') {
      const panel = document.getElementById('fb-deal-panel');
      if (panel) {
        panelVisible = !panelVisible;
        panel.classList.toggle('hidden', !panelVisible);
      }
      sendResponse({ panelVisible });
    }
  });

  // Start
  chrome.storage.local.get(['enabled', 'collectorName'], (result) => {
    const hasName = result.collectorName && result.collectorName.trim().length > 0;
    enabled = hasName && result.enabled !== false;
    // Create the activity panel
    createPanel();
    if (!hasName) {
      logEntry('warn', 'Scraping disabled — set your Collector Name in the extension popup first.');
    } else {
      logEntry('info', `Extension loaded. Collector: ${result.collectorName}. Enabled: ${enabled}`);
    }
    updateStats();

    if (enabled) {
      if (getFeed()) {
        startObserving();
      } else {
        logEntry('info', 'Waiting for feed to appear...');
        const waitForFeed = setInterval(() => {
          if (getFeed()) {
            clearInterval(waitForFeed);
            startObserving();
          }
        }, 1000);
        setTimeout(() => clearInterval(waitForFeed), 30000);
      }
    }
  });
})();
