const $ = (id) => document.getElementById(id);

// Show version from manifest
$('extVersion').textContent = 'v' + chrome.runtime.getManifest().version;

/* ───────── Supabase Health Check ───────── */

async function checkSupabase() {
  try {
    // Import config values by reading them from background
    const resp = await fetch(chrome.runtime.getURL('config.js'));
    const text = await resp.text();
    const urlMatch = text.match(/SUPABASE_URL\s*=\s*['"]([^'"]+)['"]/);
    const url = urlMatch?.[1];

    if (!url || url.includes('YOUR_PROJECT_ID')) {
      $('statusDot').classList.remove('connected');
      $('statusText').textContent = 'Supabase not configured';
      return false;
    }

    const check = await fetch(`${url}/rest/v1/`, {
      method: 'HEAD',
      signal: AbortSignal.timeout(3000),
    });
    if (check.ok || check.status === 401) {
      // 401 is expected without auth — means Supabase is reachable
      $('statusDot').classList.add('connected');
      $('statusText').textContent = 'Supabase connected';
      return true;
    }
  } catch (e) {}
  $('statusDot').classList.remove('connected');
  $('statusText').textContent = 'Supabase unreachable';
  return false;
}

/* ───────── Queue Stats ───────── */

function refreshStats() {
  chrome.runtime.sendMessage({ type: 'GET_QUEUE_STATS' }, (stats) => {
    if (chrome.runtime.lastError || !stats) return;
    $('queuedCount').textContent = (stats.queued || 0) + (stats.syncing || 0);
    $('syncedCount').textContent = stats.synced || 0;
    $('errorCount').textContent = stats.error || 0;
    $('totalCount').textContent = stats.total || 0;
  });
}

/* ───────── Load Settings ───────── */

chrome.storage.local.get(['collectorName', 'enabled'], (config) => {
  const name = config.collectorName || '';
  $('collectorName').value = name;
  // Only allow enabled if collector name is set
  const hasName = name.trim().length > 0;
  $('toggleCapture').checked = hasName && config.enabled !== false;
  $('toggleCapture').disabled = !hasName;
  if (!hasName) {
    $('syncStatus').textContent = 'Set your Collector Name to start scraping';
    $('syncStatus').style.color = '#f59e0b';
  }
});

checkSupabase();
refreshStats();

/* ───────── Toggle Capture ───────── */

$('toggleCapture').addEventListener('change', (e) => {
  const enabled = e.target.checked;
  const name = $('collectorName').value.trim();

  if (enabled && !name) {
    e.target.checked = false;
    $('savedMsg').textContent = 'Set your Collector Name first';
    $('savedMsg').style.color = '#ef4444';
    $('savedMsg').classList.add('show');
    setTimeout(() => $('savedMsg').classList.remove('show'), 3000);
    return;
  }

  chrome.storage.local.set({ enabled });

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, { type: 'TOGGLE', enabled });
    }
  });
});

/* ───────── Save Settings ───────── */

$('btnSave').addEventListener('click', () => {
  const collectorName = $('collectorName').value.trim();

  if (!collectorName) {
    $('savedMsg').textContent = 'Collector name is required';
    $('savedMsg').style.color = '#ef4444';
    $('savedMsg').classList.add('show');
    setTimeout(() => $('savedMsg').classList.remove('show'), 2000);
    return;
  }

  chrome.storage.local.set({ collectorName }, () => {
    $('toggleCapture').disabled = false;
    $('syncStatus').textContent = '';
    $('syncStatus').style.color = '';
    $('savedMsg').textContent = 'Settings saved';
    $('savedMsg').style.color = '#22c55e';
    $('savedMsg').classList.add('show');
    setTimeout(() => $('savedMsg').classList.remove('show'), 2000);
  });
});

/* ───────── Sync Now ───────── */

$('btnSync').addEventListener('click', () => {
  $('btnSync').disabled = true;
  $('syncStatus').textContent = 'Syncing...';

  chrome.runtime.sendMessage({ type: 'SYNC_NOW' }, (result) => {
    $('btnSync').disabled = false;
    if (chrome.runtime.lastError) {
      $('syncStatus').textContent = 'Sync failed: ' + chrome.runtime.lastError.message;
      return;
    }
    if (result?.success) {
      $('syncStatus').textContent = `Synced ${result.synced || 0} posts` +
        (result.errors ? `, ${result.errors} errors` : '');
    } else {
      $('syncStatus').textContent = result?.error || 'Sync failed';
    }
    refreshStats();
    setTimeout(() => { $('syncStatus').textContent = ''; }, 5000);
  });
});

/* ───────── Export JSON ───────── */

$('btnExport').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'EXPORT_QUEUE' }, (result) => {
    if (chrome.runtime.lastError || !result?.success) {
      $('syncStatus').textContent = 'Export failed';
      setTimeout(() => { $('syncStatus').textContent = ''; }, 3000);
      return;
    }

    if (result.data.length === 0) {
      $('syncStatus').textContent = 'No unsynced posts to export';
      setTimeout(() => { $('syncStatus').textContent = ''; }, 3000);
      return;
    }

    const blob = new Blob([JSON.stringify(result.data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `fb-deals-export-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);

    $('syncStatus').textContent = `Exported ${result.data.length} posts`;
    setTimeout(() => { $('syncStatus').textContent = ''; }, 3000);
  });
});

/* ───────── Clear Synced ───────── */

$('btnClearSynced').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'CLEAR_SYNCED' }, (result) => {
    if (result?.success) {
      refreshStats();
      $('syncStatus').textContent = 'Synced records cleared';
      setTimeout(() => { $('syncStatus').textContent = ''; }, 3000);
    }
  });
});
