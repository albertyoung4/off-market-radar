-- ============================================================
-- FB Deal Scraper — Poster Tracking Migration
-- Run this in the Supabase SQL Editor for your project.
-- ============================================================

-- 1. Create the posters table
CREATE TABLE IF NOT EXISTS posters (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fb_name          TEXT NOT NULL DEFAULT '',
  fb_profile_url   TEXT UNIQUE,
  phones           TEXT[] DEFAULT '{}',
  emails           TEXT[] DEFAULT '{}',
  first_seen_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_seen_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. Link deals back to posters + add post timestamp
ALTER TABLE fb_deal_posts
  ADD COLUMN IF NOT EXISTS poster_id UUID REFERENCES posters(id);

ALTER TABLE fb_deal_posts
  ADD COLUMN IF NOT EXISTS post_timestamp TEXT;

-- 3. RLS — anon can only execute the upsert function (no direct table access needed)
ALTER TABLE posters ENABLE ROW LEVEL SECURITY;

-- 4. Upsert function (SECURITY DEFINER runs as the table owner, bypassing RLS)
--    Called by the extension to find-or-create a poster and merge contact info.
CREATE OR REPLACE FUNCTION upsert_poster(
  p_fb_name        TEXT,
  p_fb_profile_url TEXT,
  p_phones         TEXT[],
  p_emails         TEXT[]
) RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_id UUID;
BEGIN
  -- Look up by profile URL first (most stable identifier), then by name
  IF p_fb_profile_url IS NOT NULL AND p_fb_profile_url <> '' THEN
    SELECT id INTO v_id FROM posters WHERE fb_profile_url = p_fb_profile_url;
  END IF;

  IF v_id IS NULL AND p_fb_name <> '' THEN
    SELECT id INTO v_id FROM posters WHERE fb_name = p_fb_name LIMIT 1;
  END IF;

  IF v_id IS NOT NULL THEN
    -- Merge new contact info into existing record
    UPDATE posters SET
      fb_profile_url = COALESCE(NULLIF(p_fb_profile_url, ''), fb_profile_url),
      phones = (
        SELECT COALESCE(ARRAY_AGG(DISTINCT phone), '{}')
        FROM (
          SELECT UNNEST(phones) AS phone
          UNION
          SELECT UNNEST(p_phones)
        ) t
        WHERE phone IS NOT NULL AND phone <> ''
      ),
      emails = (
        SELECT COALESCE(ARRAY_AGG(DISTINCT email), '{}')
        FROM (
          SELECT UNNEST(emails) AS email
          UNION
          SELECT UNNEST(p_emails)
        ) t
        WHERE email IS NOT NULL AND email <> ''
      ),
      last_seen_at = NOW()
    WHERE id = v_id;
  ELSE
    -- New poster
    INSERT INTO posters (fb_name, fb_profile_url, phones, emails)
    VALUES (
      p_fb_name,
      NULLIF(p_fb_profile_url, ''),
      p_phones,
      p_emails
    )
    RETURNING id INTO v_id;
  END IF;

  RETURN v_id;
END;
$$;

-- 5. Track which scraper version captured each post
ALTER TABLE fb_deal_posts
  ADD COLUMN IF NOT EXISTS scraper_version TEXT;

-- 6. Grant execute to the anon role so the extension can call it
GRANT EXECUTE ON FUNCTION upsert_poster(TEXT, TEXT, TEXT[], TEXT[]) TO anon;
